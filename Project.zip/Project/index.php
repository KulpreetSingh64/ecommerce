<!DOCTYPE HTML>
<html>
    <head>
        <title>Book Store</title>
    </head>
    <body>
        <?php include('includes/header1.html');?>
        <?php include('include/footer.html'); ?>
    </body>

</html>